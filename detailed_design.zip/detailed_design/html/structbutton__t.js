var structbutton__t =
[
    [ "b_in", "structbutton__t.html#a45ff1b31920c09a9b351f47ce0a520ef", null ],
    [ "b_out", "structbutton__t.html#ac938529915d1d0d0a5d0cb13306e3715", null ],
    [ "counter", "structbutton__t.html#ab36effbd4d2f9af6a0097acd75203a07", null ],
    [ "p_in", "structbutton__t.html#aad677091c6131f1cd9bfb0e939faa532", null ],
    [ "p_in_dir", "structbutton__t.html#aecf4e6bb1bdbee4a1fd005f675edb17e", null ],
    [ "p_in_pull", "structbutton__t.html#ad44cae452cddf0848ab15a2de980b841", null ],
    [ "p_in_ren", "structbutton__t.html#a93875a9a46d1b62f76ab00542f219e82", null ],
    [ "p_out", "structbutton__t.html#adfad736923133d54f4485b1a1e25f15a", null ],
    [ "p_out_dir", "structbutton__t.html#a6761859c7a3afa78f74e01b7e0883676", null ],
    [ "state", "structbutton__t.html#ab12828525693568ae9c217805bea1ef9", null ]
];