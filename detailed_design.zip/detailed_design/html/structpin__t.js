var structpin__t =
[
    [ "pin_bit", "structpin__t.html#a89e02787a0f1b5d3ee03ac4dbce8f466", null ],
    [ "pin_dir", "structpin__t.html#aa4297e354a0108de0e495ce73c170571", null ],
    [ "pin_in", "structpin__t.html#a01434d3c9c8f841300de2b1659030ba5", null ],
    [ "pin_out", "structpin__t.html#a05771b0923b8e097f990dd91ca614d81", null ],
    [ "pin_ren", "structpin__t.html#ab4f7b2d5cb812f5ac063f8a6ab8e11a2", null ]
];