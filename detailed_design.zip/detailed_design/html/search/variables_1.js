var searchData=
[
  ['last_5ftick',['last_tick',['../struct_task_control_block__t.html#a6d42e37c2adb226cd715aa7ab53f2cc4',1,'TaskControlBlock_t']]],
  ['led',['led',['../struct_task_control_block__t.html#a76a6ab22492d415daa1b3bc5849d075d',1,'TaskControlBlock_t']]]
];
