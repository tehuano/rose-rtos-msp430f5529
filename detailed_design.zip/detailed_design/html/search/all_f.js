var searchData=
[
  ['write_5flog',['write_log',['../_tasks_8c.html#adcbe71b09d4a99f6012776fb7221530e',1,'Tasks.c']]],
  ['write_5fsegc',['write_SegC',['../_tasks_8c.html#ad67040e6ac9c7cf7d8beda7bfc172ba4',1,'Tasks.c']]]
];
