var searchData=
[
  ['kernelinit',['KernelInit',['../_kernel_8h.html#a7eea669aa6b5324663924319e1fad38f',1,'KernelInit(void):&#160;Kernel.c'],['../_kernel_8c.html#a3ba5d23626883fed428934dd940001c1',1,'KernelInit():&#160;Kernel.c']]],
  ['kernelrun',['KernelRun',['../_kernel_8h.html#a4f631c168d638b94d9aa53cc9212b527',1,'KernelRun(void):&#160;Kernel.c'],['../_kernel_8c.html#ad9a2113b7397c440f92d8f386c6230ff',1,'KernelRun():&#160;Kernel.c']]]
];
