var searchData=
[
  ['sp',['sp',['../struct_task_control_block__t.html#af2277233edfb7dda4e314fedb0e10ee3',1,'TaskControlBlock_t']]],
  ['state',['state',['../struct_task_control_block__t.html#aebc38c74e1bb052cdefe524ef4806f2b',1,'TaskControlBlock_t']]]
];
