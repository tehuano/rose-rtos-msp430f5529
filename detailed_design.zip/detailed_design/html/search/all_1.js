var searchData=
[
  ['kernel_2eh',['Kernel.h',['../_kernel_8h.html',1,'']]],
  ['kernelinit',['KernelInit',['../_kernel_8h.html#a7eea669aa6b5324663924319e1fad38f',1,'Kernel.c']]],
  ['kernelrun',['KernelRun',['../_kernel_8h.html#a4f631c168d638b94d9aa53cc9212b527',1,'Kernel.c']]]
];
