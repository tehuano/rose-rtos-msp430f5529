var searchData=
[
  ['dequeue',['dequeue',['../list_8h.html#a37ab100430d7bb823f58db821b229a8b',1,'dequeue(list_t *l):&#160;list.c'],['../list_8c.html#a33188f9e5f3acde152ad706c9eabb5ba',1,'dequeue(list_t *s):&#160;list.c']]]
];
