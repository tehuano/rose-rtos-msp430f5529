var searchData=
[
  ['hardwaregettick',['HardwareGetTick',['../_hardware_8h.html#aae14aace80fb6e9befd9aa5b191e8b32',1,'HardwareGetTick():&#160;Hardware.c'],['../_hardware_8c.html#aae14aace80fb6e9befd9aa5b191e8b32',1,'HardwareGetTick():&#160;Hardware.c']]],
  ['hardwareinittimera2',['HardwareInitTimerA2',['../_hardware_8h.html#a6985217bf2fb28c491bdd3ae61c20ee4',1,'HardwareInitTimerA2():&#160;Hardware.c'],['../_hardware_8c.html#a6985217bf2fb28c491bdd3ae61c20ee4',1,'HardwareInitTimerA2():&#160;Hardware.c']]]
];
