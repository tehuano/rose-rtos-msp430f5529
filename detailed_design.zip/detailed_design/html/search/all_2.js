var searchData=
[
  ['enqueue',['enqueue',['../list_8h.html#a930266f4aae052bdf3d370116dc43281',1,'enqueue(list_t *l, node_t *n):&#160;list.c'],['../list_8c.html#a7aa2aa8b1a7daf307f9e2b7918ff9134',1,'enqueue(list_t *s, node_t *p):&#160;list.c']]],
  ['evaluate_5fbutton',['evaluate_button',['../_tasks_8c.html#aeed25a2357d0e9a03e67636d48f9bae8',1,'Tasks.c']]]
];
