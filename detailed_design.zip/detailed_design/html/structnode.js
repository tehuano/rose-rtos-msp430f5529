var structnode =
[
    [ "id", "structnode.html#a35fc2aadb5f638d5cc76810431d956c7", null ],
    [ "next", "structnode.html#a0dc1b6470487aa86d9936e3cab8b95be", null ],
    [ "prev", "structnode.html#a530843171ca1a6e033bac999737cb184", null ]
];