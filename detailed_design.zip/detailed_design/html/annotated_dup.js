var annotated_dup =
[
    [ "button_t", "structbutton__t.html", "structbutton__t" ],
    [ "list", "structlist.html", "structlist" ],
    [ "node", "structnode.html", "structnode" ],
    [ "pin_t", "structpin__t.html", "structpin__t" ],
    [ "TaskControlBlock_t", "struct_task_control_block__t.html", "struct_task_control_block__t" ]
];