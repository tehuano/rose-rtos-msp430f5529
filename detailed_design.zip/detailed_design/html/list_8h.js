var list_8h =
[
    [ "node", "structnode.html", "structnode" ],
    [ "list", "structlist.html", "structlist" ],
    [ "list_t", "list_8h.html#a15376354e4e8b4f1732e9df17f30786c", null ],
    [ "node_t", "list_8h.html#a7c02633e18d6aa5f58539b75f08753d9", null ],
    [ "VAL_SUCC", "list_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba344fab15adf4c0bc6177505a86e7e1df", null ],
    [ "VAL_ERR", "list_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba6b2c64e7fcf363f2cff1cc36677954ef", null ],
    [ "dequeue", "list_8h.html#a37ab100430d7bb823f58db821b229a8b", null ],
    [ "enqueue", "list_8h.html#a930266f4aae052bdf3d370116dc43281", null ]
];