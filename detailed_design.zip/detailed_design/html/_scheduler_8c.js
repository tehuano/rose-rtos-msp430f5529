var _scheduler_8c =
[
    [ "Scheduler_InitTasks", "_scheduler_8c.html#a5decc6eb8d8d97382850985c8932c996", null ],
    [ "Scheduler_RunTasks", "_scheduler_8c.html#a18d71fc133c92f9ed3c041b62d9c7904", null ],
    [ "task_state_transition", "_scheduler_8c.html#a320c072bcbb285812605576ec537944d", null ],
    [ "update_ready_list", "_scheduler_8c.html#a316e7b1325208119b26607b85377e54a", null ],
    [ "ci_time", "_scheduler_8c.html#a58fb10121051e2a3aaf301bc99a42846", null ],
    [ "tasks_init_done", "_scheduler_8c.html#a3d9c2dee5ac51bbe4b4ba1d8a0feedb3", null ]
];