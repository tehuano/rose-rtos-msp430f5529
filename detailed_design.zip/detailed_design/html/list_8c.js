var list_8c =
[
    [ "dequeue", "list_8c.html#a33188f9e5f3acde152ad706c9eabb5ba", null ],
    [ "enqueue", "list_8c.html#a7aa2aa8b1a7daf307f9e2b7918ff9134", null ]
];