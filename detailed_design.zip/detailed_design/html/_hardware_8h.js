var _hardware_8h =
[
    [ "button_t", "structbutton__t.html", "structbutton__t" ],
    [ "pin_t", "structpin__t.html", "structpin__t" ],
    [ "FALSE", "_hardware_8h.html#aa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "NUM_OF_INTERRUPTS_ERROR", "_hardware_8h.html#a726723695d32385a37414fcd78bdc078", null ],
    [ "TRUE", "_hardware_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "falling_edge_pin", "_hardware_8h.html#a3bc1bcf2de4a43b0914b2bf600084af8", null ],
    [ "HardwareGetTick", "_hardware_8h.html#aae14aace80fb6e9befd9aa5b191e8b32", null ],
    [ "HardwareInitTimerA2", "_hardware_8h.html#a6985217bf2fb28c491bdd3ae61c20ee4", null ],
    [ "low_pulse_pin", "_hardware_8h.html#a2171af9f84d875facd83b4fb371d8953", null ],
    [ "rising_edge_pin", "_hardware_8h.html#a61629a2126ec8b31e0b6189a60ec4d31", null ],
    [ "start_output_pin", "_hardware_8h.html#a183cee634488e9df12a5cbb426daa929", null ]
];