var _task___cfg_8c =
[
    [ "ready_list", "_task___cfg_8c.html#ac0db38908cb0088fe6e7a86f0fd51a11", null ],
    [ "Tasks", "_task___cfg_8c.html#ab4cdc47a9ac30217629481bce701a66d", null ],
    [ "tasks_ids", "_task___cfg_8c.html#a90b32f7049b34dd5bdd4e2ecc484912c", null ]
];