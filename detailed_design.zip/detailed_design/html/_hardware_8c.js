var _hardware_8c =
[
    [ "falling_edge_pin", "_hardware_8c.html#a3bc1bcf2de4a43b0914b2bf600084af8", null ],
    [ "HardwareGetTick", "_hardware_8c.html#aae14aace80fb6e9befd9aa5b191e8b32", null ],
    [ "HardwareInitTimerA2", "_hardware_8c.html#a6985217bf2fb28c491bdd3ae61c20ee4", null ],
    [ "low_pulse_pin", "_hardware_8c.html#a2171af9f84d875facd83b4fb371d8953", null ],
    [ "rising_edge_pin", "_hardware_8c.html#a61629a2126ec8b31e0b6189a60ec4d31", null ],
    [ "start_output_pin", "_hardware_8c.html#a183cee634488e9df12a5cbb426daa929", null ],
    [ "Timer_A2", "_hardware_8c.html#a8df61ff2743811817bd0d685107541a9", null ]
];