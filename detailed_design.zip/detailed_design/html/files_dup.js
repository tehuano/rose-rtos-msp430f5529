var files_dup =
[
    [ "Hardware.c", "_hardware_8c.html", "_hardware_8c" ],
    [ "Hardware.h", "_hardware_8h.html", "_hardware_8h" ],
    [ "Kernel.c", "_kernel_8c.html", "_kernel_8c" ],
    [ "Kernel.h", "_kernel_8h.html", "_kernel_8h" ],
    [ "list.c", "list_8c.html", "list_8c" ],
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main.h", "main_8h.html", null ],
    [ "Scheduler.c", "_scheduler_8c.html", "_scheduler_8c" ],
    [ "Scheduler.h", "_scheduler_8h.html", "_scheduler_8h" ],
    [ "Task_Cfg.c", "_task___cfg_8c.html", "_task___cfg_8c" ],
    [ "Task_Cfg.h", "_task___cfg_8h.html", "_task___cfg_8h" ],
    [ "Tasks.c", "_tasks_8c.html", "_tasks_8c" ],
    [ "Tasks.h", "_tasks_8h_source.html", null ]
];