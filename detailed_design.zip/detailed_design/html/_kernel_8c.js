var _kernel_8c =
[
    [ "KernelInit", "_kernel_8c.html#a3ba5d23626883fed428934dd940001c1", null ],
    [ "KernelRun", "_kernel_8c.html#ad9a2113b7397c440f92d8f386c6230ff", null ],
    [ "event_vector", "_kernel_8c.html#ad365c04476d6b1218a9308e0f39cdfbd", null ]
];