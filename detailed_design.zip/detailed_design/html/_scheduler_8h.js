var _scheduler_8h =
[
    [ "TaskControlBlock_t", "struct_task_control_block__t.html", "struct_task_control_block__t" ],
    [ "PREEMTIVE", "_scheduler_8h.html#ac1f4a87fc890a0da898bcf6510de6c89", null ],
    [ "STD_OFF", "_scheduler_8h.html#a06b00117603b302dddd3e5a16e355e60", null ],
    [ "STD_ON", "_scheduler_8h.html#aa751842079e9148271cfc8acb6016a9b", null ],
    [ "TaskState", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bce", [
      [ "BLOCKED", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bcea376c1b6a3f75d283a2efacf737438d61", null ],
      [ "READY", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bcea6564f2f3e15be06b670547bbcaaf0798", null ],
      [ "RUNNING", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bcea1061be6c3fb88d32829cba6f6b2be304", null ],
      [ "ENABLED", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bcea99788d1f27bac42d0c7bac63026c5959", null ],
      [ "DISABLED", "_scheduler_8h.html#a724f9ce2351c125b3b7f6c7923822bcea40f39385238042f6ec0cbac821a19fc4", null ]
    ] ],
    [ "Scheduler_InitTasks", "_scheduler_8h.html#acec874db1fd3b6cfe323f52fe3939270", null ],
    [ "Scheduler_RunTasks", "_scheduler_8h.html#abcfb2f376f1e7f52c9abc65d33dd5f69", null ],
    [ "task_state_transition", "_scheduler_8h.html#a320c072bcbb285812605576ec537944d", null ],
    [ "update_ready_list", "_scheduler_8h.html#a316e7b1325208119b26607b85377e54a", null ]
];