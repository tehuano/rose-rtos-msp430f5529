var structlist =
[
    [ "head", "structlist.html#a2c8cf972a56a897701e0f301da9d0aae", null ],
    [ "tail", "structlist.html#a1693ff919b1a3e0231c07af7bde37301", null ]
];