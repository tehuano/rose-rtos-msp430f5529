var _task___cfg_8h =
[
    [ "FLASH_WRITE_EVENT", "_task___cfg_8h.html#a737c78c1463af8f7425ac1aa5079eb54", null ],
    [ "NUMBER_OF_TASKS", "_task___cfg_8h.html#ada6bcbd5d0953c77599855f58861c27b", null ],
    [ "ready_list", "_task___cfg_8h.html#ac0db38908cb0088fe6e7a86f0fd51a11", null ],
    [ "Tasks", "_task___cfg_8h.html#ab4cdc47a9ac30217629481bce701a66d", null ],
    [ "tasks_ids", "_task___cfg_8h.html#a90b32f7049b34dd5bdd4e2ecc484912c", null ]
];